package com.gui;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvException;
import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JTextFieldDateEditor;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Properties;

public class mainForm {
    private JPanel panel1;
    private JButton btConvert;
    private JComboBox<String> cmbUploadType;
    private JTextField tfDebitAccount;
    private JTextField tfAccountDescription;
    private JComboBox cmbInstructionAt;
    private JDateChooser fieldIntrustionDate;
    private JComboBox cmbChargeTo;
    private JComboBox cmbChargeType;
    private JLabel logo;
    private JLabel dcc;
    private static JFrame parent;

    private static Properties prop;

    private static SimpleDateFormat format;

    private static String debitAccount;
    private static String descriptionAccount;
    private static String instructionAt="";
    private static String instructionDate="";
    private static String chargeType;
    private static String chargeTo;

    private static String productCode;

    private static Long startTime;

    private static DecimalFormat df2 = new DecimalFormat("###.###");

    public static void main(String[] args){
        prop= new Properties();
        String properties= "app.config";

        InputStream config = null;
        try {
            config = new FileInputStream(properties);
            prop.load(config);
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (!checkConfigFile()){
            System.exit(0);
        }

        deleteFileOut(new File(prop.getProperty("app.folder_out")));
        showGUI();
    }

    private static boolean checkConfigFile(){
        File folderIN= new File(prop.getProperty("app.folder_in"));
        File folderOUT= new File(prop.getProperty("app.folder_out"));

        boolean status= true;

        if (!folderIN.exists()){
            JOptionPane.showMessageDialog(parent, "Check config file\nfolder in not found ");
            status= false;
        }

        if(!folderOUT.exists()){
            JOptionPane.showMessageDialog(parent, "Check config file\nfolder out not found");
            status= false;
        }

//        System.out.println(prop.getProperty("app.instruction_at").length());
        if(prop.getProperty("app.debit_account_no").length()>12){
            JOptionPane.showMessageDialog(parent, "Check config file\nCredit Account No couldn't be more than 34");
            status= false;
        }

        if(prop.getProperty("app.account_description").length()>60){
            JOptionPane.showMessageDialog(parent, "Check config file\nCredit Account No couldn't be more than 50");
            status= false;
        }

        if(prop.getProperty("app.credit_account_currency_code").length()>3 ||
                prop.getProperty("app.credit_account_currency_code").length()<3){
            JOptionPane.showMessageDialog(parent, "Check config file\nCredit Account No couldn't be more or less than 3");
            status= false;
        }

        if(prop.getProperty("app.instruction_at").length()>4 ||
                prop.getProperty("app.instruction_at").length()<4){
            JOptionPane.showMessageDialog(parent, "Check config file\nInstruction at couldn't be more or less than 4");
            status= false;
        }

        return status;
    }

    private static void deleteFileOut(File file) {
        for(File del: Objects.requireNonNull(file.listFiles())){
            del.delete();
        }
    }

    private void createUIComponents() {
        logo= new JLabel();
        fieldIntrustionDate = new JDateChooser();
    }
    
    private mainForm(){
        parent = new JFrame();
        parent.add(panel1);


        logo.setIcon(new ImageIcon(ClassLoader.getSystemResource("res/danamon.jpg")));
        logo.validate();

        dcc.setIcon(new ImageIcon(ClassLoader.getSystemResource("res/dcc.png")));
        dcc.validate();
        /**
         * HAC= Inhouse
         * HYR= Payroll
         * */
        cmbUploadType.addItem("Inhouse");
        cmbUploadType.addItem("Payroll");
        String uploadType=prop.getProperty("app.bulk_upload");
        if(checkingUploadTypeConfig(uploadType)!=null){
            cmbUploadType.setSelectedItem(checkingUploadTypeConfig(uploadType));
        }else{
            JOptionPane.showMessageDialog(parent, "Upload type not match.\n Please set correct upload type in config file.");
            System.exit(1);
        }

        /**
         * OUR= REM
         * BEN= BEN
         * */
        cmbChargeTo.addItem("OUR");
        cmbChargeTo.addItem("BEN");
        String chargeToTemp=prop.getProperty("app.charge_to");
        if (checkingChargeToConfig(chargeToTemp)!=null){
            cmbChargeTo.setSelectedItem(checkingChargeToConfig(chargeToTemp));
        }else{
            JOptionPane.showMessageDialog(parent, "Charge To not match.\n Please set correct upload type in config file.");
            System.exit(1);
        }

        cmbChargeType.addItem("Split");
        cmbChargeType.addItem("Combine");
        String chargeTypeTemp=prop.getProperty("app.charge_type");
        if (checkingChargeTypeConfig(chargeTypeTemp)!=null){
            cmbChargeType.setSelectedItem(checkingChargeTypeConfig(chargeTypeTemp));
        }else{
            JOptionPane.showMessageDialog(parent, "Charge type not match.\n Please set correct upload type in config file.");
            System.exit(1);
        }

        tfDebitAccount.setText(prop.getProperty("app.debit_account_no"));
        tfDebitAccount.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                String value = tfDebitAccount.getText();
                int l = value.length();
                if (e.getKeyChar() >= '0' && e.getKeyChar() <= '9' && e.getKeyCode()==8) {
                    tfDebitAccount.setEditable(true);
                } else {
                    tfDebitAccount.setEditable(false);
                }

                if (l<=12 || e.getKeyCode()==8){
                    tfDebitAccount.setEditable(true);
                }else{
                    tfDebitAccount.setEditable(false);
                }
            }
        });

        tfAccountDescription.setText(prop.getProperty("app.account_description"));
        tfAccountDescription.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                String value = tfAccountDescription.getText();
                int l = value.length();
                if (l<=60 || e.getKeyCode()==8){
                    tfAccountDescription.setEditable(true);
                }else{
                    tfAccountDescription.setEditable(false);
                }
            }
        });

        fieldIntrustionDate.setDateFormatString("yyyy/MM/dd");
        JTextFieldDateEditor editor = (JTextFieldDateEditor) fieldIntrustionDate.getDateEditor();
        editor.setEditable(false);
        format = new SimpleDateFormat("yyyyMMdd");

        cmbInstructionAt.addItem("0700");
        cmbInstructionAt.addItem("1000");
        cmbInstructionAt.addItem("1300");
        cmbInstructionAt.addItem("1600");
        cmbInstructionAt.addItem("");
        cmbInstructionAt.setSelectedItem(prop.getProperty("app.instruction_at"));

        btConvert.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btConvert.setEnabled(false);

                boolean status = true;
                debitAccount= tfDebitAccount.getText();
                if (debitAccount.equals("")){
                    status= false;
                    JOptionPane.showMessageDialog(parent, "Please fill debit account");
                }
                descriptionAccount= tfAccountDescription.getText();
                instructionAt = (String) cmbInstructionAt.getSelectedItem();
                if(fieldIntrustionDate.getDate()!=null) {
                    DateTimeFormatter dtf = DateTimeFormat.forPattern("yyyyMMdd");
                    DateTimeFormatter dtfTime= DateTimeFormat.forPattern("HHmm");
                    LocalDateTime now = LocalDateTime.now();
                    String timeNow= now.toString(dtfTime);
                    if (format.format(fieldIntrustionDate.getDate()).compareTo(now.toString(dtf))==0){
                        if (timeNow.compareTo(instructionAt)>0){
                            status= false;
                            JOptionPane.showMessageDialog(parent, "Instruction At (set in configuration file) has been passed");
                        }
                    }
                    if (format.format(fieldIntrustionDate.getDate()).compareTo(now.toString(dtf))<0){
                        status= false;
                        JOptionPane.showMessageDialog(parent, "Instruction Date must be empty or equal or greater than today.");
                    }
                    instructionDate = format.format(fieldIntrustionDate.getDate());
                }else{
                    instructionAt="";
                }

                productCode= convertUploadType(cmbUploadType.getSelectedItem());

                chargeType= convertChargeType(cmbChargeType.getSelectedItem());

                chargeTo= convertChargeTo(cmbChargeTo.getSelectedItem());
                
                if (status==true) {
                    convert();
                }
                btConvert.setEnabled(true);
            }
        });
    }

    private static String checkingChargeTypeConfig(String property) {
        if (property.equals("S")){
            return "Split";
        }else if(property.equals("C")){
            return "Combine";
        }
        return null;
    }
    private static String checkingUploadTypeConfig(String property){
        if (property.equals("HAC")){
            return "Inhouse";
        }else if (property.equals("HYR")){
            return "Payroll";
        }
        return null;
    }
    private static String checkingChargeToConfig(String property){
        if (property.equals("OUR")){
            return "REM";
        }else if(property.equals("BEN")){
            return "BEN";
        }
        return null;
    }

    private static String convertChargeTo(Object selectedItem){
        if (selectedItem.equals("OUR")){
            return "REM";
        }
        return "BEN";

    }
    private static String convertChargeType(Object selectedItem){
        if (selectedItem.equals("Split")){
            return "S";
        }
        return "C";

    }
    private static String convertUploadType(Object selectedItem){
        if (selectedItem.equals("Inhouse")){
            return "HAC";
        }
        return "HYR";

    }

    private static void showGUI(){
        JFrame frame = new JFrame("Converter Auto-Credit V1.0");//manggilframe
        frame.setContentPane(new mainForm().panel1);//manggil guiform
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//biar bisa di close
        frame.setResizable(false);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);//biar tampil
    }

    private static void convert(){
        File dir= new File(prop.getProperty("app.folder_in"));
        String[] fileList= dir.list();

        if (fileList.length==0){
            JOptionPane.showMessageDialog(parent, "File conversion error!! Please check the input file.");
        }
        int recordCount;
        for (String nameFile: fileList){
            recordCount=0;
            startTime= null;
            startTime = System.nanoTime();
            try {
                FileReader fileReader = new FileReader(prop.getProperty("app.folder_in")+nameFile);
                CSVReader csvReader = new CSVReader(fileReader);
                List<String[]> records = csvReader.readAll();

                if (!checkingFileStructure(records, nameFile)){
                    continue;
                }

                String[] out= nameFile.split("\\.");
                File file = new File(prop.getProperty("app.folder_out")+ out[0]+ ".csv");
                //menghasilkan output di folder OUT sesuai nama folder IN
                FileWriter outputfile = new FileWriter(file);
                CSVWriter writer = new CSVWriter(outputfile, ',', '\u0000', '\u0000', "\n");

                writer.writeNext(new String[]{"H", debitAccount, descriptionAccount, "S", "Y", "", instructionDate, instructionAt, ""});

                for (String[] record:records){
                    recordCount+=1;
                    int length= record.length-1;
                    String email="";
                    if(length == 6){
                        email= record[4]+";"+record[5]+";"+record[6];
                    }else if(length==5){
                        email= record[4]+";"+record[5];
                    }else if(length==4){
                        email= record[4];
                    }
//                    writer.writeNext(new String[]{"D", productCode, "", "", "", "", "", "", "", record[0], "", "",
//                            "", "", "",email, "", record[2], record[3], "", "", record[1], "", "", chargeTo, chargeType, "", "", "", "",
//                            "", "", "", "", "", "", "", "", ""});
                    writer.writeNext(new String[]{"D", productCode, "", "", record[2], "", "",
                            "", "", record[0],"", "", "", "", "", email, "", "", record[3], "", "", record[1], "", "",
                            chargeTo,chargeType, "", "", "", "", "Y", "", "", "", "", "", "", "", ""});
                }

                long endTime   = System.nanoTime();
                long totalTime = endTime - startTime;
                double sec= (double) totalTime/1000000000;
                int seconds= (int)sec;
                JOptionPane.showMessageDialog(parent, "Successfully converting "+recordCount+" record(s) \n in "+df2.format(sec)+" seconds");

                writer.close();
            } catch (IOException | ArrayIndexOutOfBoundsException e) {
                JOptionPane.showMessageDialog(parent, "File conversion error!! Please check the input file.");
//                e.printStackTrace();
            }

        }
    }

    private static boolean checkingFileStructure(List<String[]> records, String nameFile) {
        int rowCount=0;
        String[] rowError = new String[records.size()];
        String[] delimiterError = new String[records.size()];
        String[] amountError = new String[records.size()];
        int count=0;
        int delimiterCount= 0;
        int amountCount= 0;

        boolean status= true;

        boolean statusRow= true;
        boolean statusDelimiter= true;
        boolean statusAmmount= true;

        for (String[] record:records){
            rowCount+=1;
            int length= record.length-1;
            if (length<3 || length>6){
                statusRow= false;
                rowError[count]= String.valueOf(rowCount);
                count+=1;
            }

            if(Arrays.toString(record).contains(";")){
                statusDelimiter= false;
                delimiterError[delimiterCount]= String.valueOf(rowCount);
                delimiterCount+=1;
            }

            try{
                String[] amount= record[1].split("\\.");
                System.out.println(amount[1].length());
                if (amount[1].length()>2){
                    statusAmmount= false;
                    amountError[amountCount]= String.valueOf(rowCount);
                    amountCount+=1;
                }
            }catch (Exception e){
//                statusAmmount= false;
//                amountError[amountCount]= String.valueOf(rowCount);
//                System.out.println("error");
//                amountCount+=1;
            }
        }
        if (!statusRow){
            String[] errorCount= new String[count];
            System.arraycopy(rowError, 0, errorCount, 0, count);
//            JOptionPane.showMessageDialog(parent, "Error file "+ nameFile+" row "+ Arrays.toString(errorCount).replace("[","").replace("]", ""));
            JOptionPane.showMessageDialog(parent, "Error file "+ nameFile+" row "+ Arrays.toString(errorCount)
                    .replace("[","").replace("]", "")
                    .replaceAll("(.15)", "$0\n"));
            status= false;
        }

        if (!statusAmmount){
            String[] errorCount= new String[amountCount];
            System.arraycopy(amountError, 0, errorCount, 0, amountCount);
//            JOptionPane.showMessageDialog(parent, "Error file "+ nameFile+" row "+ Arrays.toString(errorCount).replace("[","").replace("]", ""));
            JOptionPane.showMessageDialog(parent, "Check amount \nError file "+ nameFile+" row "+ Arrays.toString(errorCount)
                    .replace("[","").replace("]", "")
                    .replaceAll("(.15)", "$0\n"));
            status= false;
        }

        if (!statusDelimiter){
            String[] errorCount= new String[delimiterCount];
            System.arraycopy(delimiterError, 0, errorCount, 0, delimiterCount);
//            JOptionPane.showMessageDialog(parent, "Error file "+ nameFile+" row "+ Arrays.toString(errorCount).replace("[","").replace("]", ""));
            JOptionPane.showMessageDialog(parent, "Delimiter should be ','\nCheck delimiter file "+ nameFile+" row "+ Arrays.toString(errorCount)
                    .replace("[","").replace("]", "")
                    .replaceAll("(.15)", "$0\n"));
            status= false;
        }

        return status;

    }

}
